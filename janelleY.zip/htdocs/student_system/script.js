// Toggle between Form and Table
function toggleView(sectionId) {
    document.getElementById('view-section').classList.add('hidden');
    document.getElementById('form-section').classList.add('hidden');
    document.getElementById(sectionId).classList.remove('hidden');
}

// Client-side Validation & Mock CRUD
document.getElementById('studentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const email = document.getElementById('email').value;
    const course = document.getElementById('course').options[document.getElementById('course').selectedIndex].text;

    if(age < 18) {
        alert("Student must be at least 18 years old.");
        return;
    }

    // Add to table (Mocking the database response)
    const tableBody = document.getElementById('studentData');
    const newRow = `
        <tr>
            <td>${name}</td>
            <td>${age}</td>
            <td>${email}</td>
            <td>${course}</td>
            <td>
                <button class="delete-btn" onclick="this.parentElement.parentElement.remove()">Delete</button>
            </td>
        </tr>
    `;
    
    tableBody.innerHTML += newRow;
    alert("Student added successfully!");
    this.reset();
    toggleView('view-section');
});