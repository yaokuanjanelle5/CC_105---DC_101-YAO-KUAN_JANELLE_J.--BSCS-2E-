<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $course_id = $_POST['course'];

    $sql = "INSERT INTO students (name, age, email, course_id) 
            VALUES ('$name', $age, '$email', $course_id)";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?success=1");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>