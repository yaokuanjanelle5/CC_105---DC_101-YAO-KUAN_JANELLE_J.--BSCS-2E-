<?php
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM students WHERE student_id = $id");
$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Edit Student</title>
</head>
<body>
    <div class="content">
        <div class="card">
            <h3>Update Student Information</h3>
            <form action="update_process.php" method="POST">
                <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo $student['name']; ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo $student['email']; ?>" required>
                </div>

                <button type="submit" class="save-btn">Update Record</button>
                <a href="index.php">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>