SQL

-- --- Student Management System SQL Script --- --

-- 1. Create Database
CREATE DATABASE IF NOT EXISTS student_system;
USE student_system;

-- 2. Create Courses Table (Parent Table)
-- Normalization: Separating courses ensures data consistency
CREATE TABLE IF NOT EXISTS courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    department VARCHAR(100) DEFAULT 'General Education'
) ENGINE=InnoDB;

-- 3. Create Students Table (Child Table)
CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    course_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- Relationship: Linking students to courses
    FOREIGN KEY (course_id) REFERENCES courses(course_id) 
    ON DELETE SET NULL 
    ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 4. Create an Audit Log Table (Optional 3rd Related Table)
-- To meet the "at least 3 related tables" requirement meaningfully
CREATE TABLE IF NOT EXISTS enrollment_history (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    action_type VARCHAR(50),
    action_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Populate Sample Data
INSERT INTO courses (course_name, department) VALUES 
('Computer Science', 'IT Department'),
('Business Administration', 'Business School'),
('Graphic Design', 'Arts & Media'),
('Mechanical Engineering', 'Engineering');

INSERT INTO students (name, age, email, course_id) VALUES 
('Alice James', 20, 'alice.j@kll.edu', 1),
('Robert delacruz', 22, 'b.dc@kll.edu', 2),
('Catherine bandong', 19, 'cat.b@kll.edu', 3),
('Daniel Garcia', 21, 'd.garcia@kll.edu', 1);