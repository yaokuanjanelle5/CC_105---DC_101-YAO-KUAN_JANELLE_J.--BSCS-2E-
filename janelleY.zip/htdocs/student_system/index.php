<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal | Modern Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <div class="logo">
                <h2>Janelle Yaokuan</h2>
            </div>
            <nav>
                <button onclick="toggleView('view-section')" class="nav-btn">Dashboard</button>
                <button onclick="toggleView('form-section')" class="nav-btn btn-primary">Add New Student</button>
            </nav>
        </aside>

        <main class="content">
            <header>
                <h1>Student Management System</h1>
                <p id="date-display"></p>
            </header>

            <section id="view-section" class="card">
                <div class="card-header">
                    <h3>Student Directory</h3>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="studentData">
                            <?php
                            $sql = "SELECT students.*, courses.course_name 
                                    FROM students 
                                    LEFT JOIN courses ON students.course_id = courses.course_id";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                            <td><strong>" . htmlspecialchars($row['name']) . "</strong></td>
                                            <td>" . $row['age'] . "</td>
                                            <td>" . htmlspecialchars($row['email']) . "</td>
                                            <td><span class='badge'>" . htmlspecialchars($row['course_name']) . "</span></td>
                                            <td>
                                                <a href='edit.php?id={$row['student_id']}' class='edit-link'>Edit</a>
                                                <a href='delete.php?id={$row['student_id']}' class='delete-link' onclick='return confirm(\"Are you sure you want to delete this student?\")'>Delete</a>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' style='text-align:center;'>No students found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section id="form-section" class="card hidden">
                <div class="card-header">
                    <h3>Register New Student</h3>
                </div>
                <form id="studentForm" action="save_student.php" method="POST" onsubmit="return validateForm()">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" name="name" id="name" required placeholder="Enter full name">
                        </div>
                        <div class="form-group">
                            <label for="age">Age</label>
                            <input type="number" name="age" id="age" required placeholder="Min 18">
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" name="email" id="email" required placeholder="email@university.edu">
                        </div>
                        <div class="form-group">
                            <label for="course">Assigned Course</label>
                            <select name="course" id="course" required>
                                <option value="">Select a Course</option>
                                <?php
                                $courses = $conn->query("SELECT * FROM courses");
                                while($c = $courses->fetch_assoc()) {
                                    echo "<option value='{$c['course_id']}'>{$c['course_name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="save-btn">Register Student</button>
                        <button type="button" onclick="toggleView('view-section')" class="cancel-btn">Cancel</button>
                    </div>
                </form>
            </section>
        </main>
    </div>

    <script src="script.js"></script>
</body>
</html>