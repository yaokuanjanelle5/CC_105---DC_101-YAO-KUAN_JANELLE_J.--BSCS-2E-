# 🎓 Student Management System

A modern, responsive web application designed to manage student records efficiently. This system allows administrators to perform Full CRUD (Create, Read, Update, Delete) operations using a PHP backend and a MySQL database.

## 🚀 Features
* **Student Directory:** View a list of all registered students with their course details.
* **Registration System:** Add new students with client-side validation.
* **Course Relationship:** Dynamic course selection linked via Foreign Keys.
* **Management Tools:** Easily update student information or remove records.
* **Modern UI:** Responsive sidebar layout with a clean, professional "Indigo" theme.

## 🛠️ Tech Stack
* **Frontend:** HTML5, CSS3 (Modern Flexbox/Grid), JavaScript (ES6)
* **Backend:** PHP
* **Database:** MySQL
* **Server:** Apache (XAMPP)

## 📂 Project Structure
```text
├── db.php              # Database connection settings
├── index.php           # Main dashboard (Read & UI)
├── save_student.php    # Create logic
├── edit.php            # Update form
├── update_process.php  # Update logic
├── delete.php          # Delete logic
├── style.css           # Modern custom styling
├── script.js           # Client-side validation & UI toggling
└── database.sql        # SQL schema export
⚙️ Installation & Setup
Clone the repository:

Bash

git clone [https://github.com/ArlynDV/](https://github.com/ArlynDV/)[Your-Repo-Name].git
Move to Server Folder: Copy all project files to your local server directory (e.g., C:/xampp/htdocs/student_system/).

Database Setup:

Open phpMyAdmin.

Create a new database named student_system.

Import the database.sql file provided in this repository.

Run the App: Open your browser and navigate to http://localhost/student_system/index.php.

📊 Database Design
The system uses a relational database model with two main tables:

courses: Stores course names (Primary Key: course_id).

students: Stores student details (Primary Key: student_id, Foreign Key: course_id).

💡 Challenges & Learning
During development, I focused on ensuring Data Integrity. One challenge was implementing the JOIN query to display course names instead of just ID numbers in the table. I also learned how to use JavaScript to switch views without page reloads, creating a more seamless "Single Page Application" feel.

📝 Evaluation Requirements Met
[x] MySQL Design: 3 related tables with normalization.

[x] CRUD Operations: Create, Read, Update, and Delete fully implemented.

[x] Web Interface: Modern, responsive CSS design.

[x] Interactivity: JS-based form validation and UI toggling.