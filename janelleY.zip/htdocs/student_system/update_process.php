<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['student_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "UPDATE students SET name='$name', email='$email' WHERE student_id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?updated=1");
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>