<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // SQL to delete a record
    $sql = "DELETE FROM students WHERE student_id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?deleted=1");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
?>