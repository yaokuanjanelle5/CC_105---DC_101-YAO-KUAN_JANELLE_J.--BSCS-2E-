<?php
$host = "localhost";
$user = "root"; // Default XAMPP user
$pass = "zenaida";     // Default XAMPP password
$dbname = "student_system";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>